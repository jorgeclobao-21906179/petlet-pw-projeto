from django.db import models

# Create your models here.
class Animal(models.Model):
    animal_type         = models.CharField(max_length=30)
    breed               = models.CharField(max_length=50)
    story               = models.TextField()
    days_in_our_care    = models.SmallIntegerField()
    health              = models.CharField(max_length=25)
    gender              = models.CharField(max_length=10)
    age                 = models.SmallIntegerField()
    featured            = models.BooleanField(blank=True, null=True)
    