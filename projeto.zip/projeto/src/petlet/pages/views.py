from django.http import HttpResponse
from django.shortcuts import render

# Create your views here.
def home(request, *args, **kwargs):
    return render(request, "home.html")

def about_us(request, *args, **kwargs):
    return render(request, "about-us.html")

def contact_us(request, *args, **kwargs):
    return render(request, "contact_us.html")

def quiz(request, *args, **kwargs):
    return render(request, "quiz.html")